# Changelog — Blonding App

## 2.1
- Fixes and improvements.
